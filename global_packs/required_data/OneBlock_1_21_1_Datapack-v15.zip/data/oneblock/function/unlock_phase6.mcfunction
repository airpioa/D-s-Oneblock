scoreboard players set @s ob_phase 6
execute unless score #global_max ob_phase matches 6.. run scoreboard players set #global_max ob_phase 6
advancement grant @a only oneblock:phase6

playsound minecraft:ui.toast.challenge_complete master @a[distance=..64] ~ ~1 ~ 0.9 1.15
playsound minecraft:entity.blaze.ambient master @a[distance=..64] ~ ~1 ~ 1.0 0.9
particle minecraft:soul_fire_flame ~ ~1.5 ~ 0.6 1.5 0.6 0.12 70
particle minecraft:end_rod ~ ~2.0 ~ 1.2 2.5 1.2 0.08 40
effect give @a[distance=..32] minecraft:slow_falling 5 0 true

title @a[distance=..64] times 12 65 18
title @a[distance=..64] subtitle {"text":"Deepslate, Obsidian, Blazes & Zombified Piglins!","color":"gray"}
title @a[distance=..64] title {"text":"✦ ACT VI: BRASS, STEAM & DIESEL POWER ✦","color":"gold","bold":true}
tellraw @a[distance=..64] ["",{"text":"\n§8§m--------------------------------------------------\n"},{"text":"  ✦ ACT VI: BRASS, STEAM & DIESEL POWER ✦\n","color":"gold","bold":true},{"text":"  Volcanic heat fractures the pedestal! Capture Blazes in Blaze Burners to fuel high-pressure Steam & Diesel Engines!\n","color":"white"},{"text":"  §7(Right-click your Act Field Manual Book or Pedestal anytime for full details!)\n"},{"text":"§8§m--------------------------------------------------"}]
