execute as @e[type=minecraft:marker,tag=ob_core] at @s if block ~ ~-1 ~ kubejs:anomaly_pedestal run setblock ~ ~-1 ~ minecraft:air
scoreboard players set #max_c ob_count -1
execute as @e[type=minecraft:marker,tag=ob_core,x=-2,y=62,z=-2,dx=4,dy=4,dz=4] run scoreboard players operation #max_c ob_count > @s ob_count
tag @e[type=minecraft:marker,tag=ob_core] remove ob_keep
execute positioned 0.5 64.0 0.5 as @e[type=minecraft:marker,tag=ob_core,distance=..2,sort=nearest] if score @s ob_count = #max_c ob_count run tag @s add ob_keep
execute positioned 0.5 64.0 0.5 as @e[type=minecraft:marker,tag=ob_keep,distance=..2,sort=nearest,limit=1] run tag @s add ob_keep_one
kill @e[type=minecraft:marker,tag=ob_core,x=-2,y=62,z=-2,dx=4,dy=4,dz=4,tag=!ob_keep_one]
tag @e[type=minecraft:marker,tag=ob_keep_one] remove ob_keep_one
tag @e[type=minecraft:marker,tag=ob_keep] remove ob_keep
execute unless score #next_id ob_id matches 2.. run scoreboard players set #next_id ob_id 2
tellraw @a {"text":"[OneBlock] Cleaned up duplicate island cores! If a friend still needs an island, run: /scoreboard players set <FriendName> ob_init 0","color":"green"}
