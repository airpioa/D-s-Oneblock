scoreboard objectives add ob_count dummy "Blocks Mined"
scoreboard objectives add ob_init dummy
scoreboard objectives add ob_phase dummy
scoreboard objectives add ob_ver dummy
scoreboard objectives add ob_id dummy "Island ID"
scoreboard objectives add ob_intro dummy
scoreboard objectives add ob_hud dummy
forceload add 0 0
execute unless score #setup ob_init matches 1 run function oneblock:setup
execute if score #setup ob_init matches 1 run function oneblock:migrate
