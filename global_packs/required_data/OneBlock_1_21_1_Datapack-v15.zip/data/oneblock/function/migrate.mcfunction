execute unless score #next_id ob_id matches 1.. run scoreboard players set #next_id ob_id 2

execute unless entity @e[type=minecraft:marker,tag=ob_core,x=-2,y=62,z=-2,dx=4,dy=4,dz=4] run summon minecraft:marker 0.5 64.0 0.5 {Tags:["ob_core","ob_island_1"]}
execute as @e[type=minecraft:marker,tag=ob_island_1] run scoreboard players set @s ob_id 1
execute if score #blocks ob_count matches 1.. as @e[type=minecraft:marker,tag=ob_island_1] unless score @s ob_count matches 1.. run scoreboard players operation @s ob_count = #blocks ob_count
execute if score #phase ob_phase matches 1.. as @e[type=minecraft:marker,tag=ob_island_1] unless score @s ob_phase matches 1.. run scoreboard players operation @s ob_phase = #phase ob_phase

execute as @e[type=minecraft:marker,tag=ob_core] at @s if block ~ ~-1 ~ kubejs:anomaly_pedestal run setblock ~ ~-1 ~ minecraft:air

execute as @e[type=minecraft:marker,tag=ob_core] run function oneblock:recalc_marker_phase
execute as @a run function oneblock:sync_advancements

execute unless score #schema ob_ver matches 15 run tellraw @a ["",{"text":"[OneBlock Pack Updated] ","color":"aqua","bold":true},{"text":"Migrated safely to v15 (Global Biome Prism & Biome Surveyor)!","color":"white"}]
scoreboard players set #schema ob_ver 15
