scoreboard players set @s ob_phase 7
execute unless score #global_max ob_phase matches 7.. run scoreboard players set #global_max ob_phase 7
advancement grant @a only oneblock:phase7

playsound minecraft:ui.toast.challenge_complete master @a[distance=..64] ~ ~1 ~ 0.9 1.15
playsound minecraft:entity.enderman.stare master @a[distance=..64] ~ ~1 ~ 1.0 0.9
particle minecraft:portal ~ ~1.5 ~ 0.6 1.5 0.6 0.12 70
particle minecraft:end_rod ~ ~2.0 ~ 1.2 2.5 1.2 0.08 40
effect give @a[distance=..32] minecraft:slow_falling 5 0 true

title @a[distance=..64] times 12 65 18
title @a[distance=..64] subtitle {"text":"Sky Stone, Certus Quartz, Diamonds & Endermen!","color":"gray"}
title @a[distance=..64] title {"text":"✦ ACT VII: DIGITAL AE2 & APPLIED MEKANISTICS ✦","color":"light_purple","bold":true}
tellraw @a[distance=..64] ["",{"text":"\n§8§m--------------------------------------------------\n"},{"text":"  ✦ ACT VII: DIGITAL AE2 & APPLIED MEKANISTICS ✦\n","color":"light_purple","bold":true},{"text":"  Meteoritic Sky Stone & spatial rifts open. Build Digital ME Networks & Chemical Storage cells!\n","color":"white"},{"text":"  §7(Right-click your Act Field Manual Book or Pedestal anytime for full details!)\n"},{"text":"§8§m--------------------------------------------------"}]
