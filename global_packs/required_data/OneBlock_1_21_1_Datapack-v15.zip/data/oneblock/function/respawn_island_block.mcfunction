scoreboard players add @s ob_count 1
particle minecraft:happy_villager ~ ~0.5 ~ 0.3 0.3 0.3 0.05 8
playsound minecraft:entity.experience_orb.pickup block @a[distance=..16] ~ ~0.5 ~ 0.4 1.2
execute if score @s ob_count matches 25 run tellraw @a[distance=..32] ["",{"text":"[Anomaly Pedestal] ","color":"yellow","bold":true},{"text":"25/50 blocks mined! Expand your platform—Mobs begin spawning in Act II!","color":"yellow"}]
execute if score @s ob_count matches 45 run tellraw @a[distance=..32] ["",{"text":"[Anomaly Pedestal] ","color":"red","bold":true},{"text":"WARNING: 5 blocks until Act II! Build a safety fence before mobs spawn!","color":"red"}]
execute if score @s ob_count matches 1..49 unless score @s ob_phase matches 2.. run scoreboard players set @s ob_phase 1
execute if score @s ob_count matches 50.. unless score @s ob_phase matches 2.. run function oneblock:unlock_phase2
execute if score @s ob_count matches 125.. unless score @s ob_phase matches 3.. run function oneblock:unlock_phase3
execute if score @s ob_count matches 225.. unless score @s ob_phase matches 4.. run function oneblock:unlock_phase4
execute if score @s ob_count matches 350.. unless score @s ob_phase matches 5.. run function oneblock:unlock_phase5
execute if score @s ob_count matches 500.. unless score @s ob_phase matches 6.. run function oneblock:unlock_phase6
execute if score @s ob_count matches 675.. unless score @s ob_phase matches 7.. run function oneblock:unlock_phase7
execute if score @s ob_count matches 850.. unless score @s ob_phase matches 8.. run function oneblock:unlock_phase8
execute if score @s ob_count matches 1050.. unless score @s ob_phase matches 9.. run function oneblock:unlock_phase9
execute if score @s ob_count matches 1275.. unless score @s ob_phase matches 10.. run function oneblock:unlock_phase10
execute if score @s ob_count matches 1525.. unless score @s ob_phase matches 11.. run function oneblock:unlock_phase11
execute if score @s ob_count matches 1800.. unless score @s ob_phase matches 12.. run function oneblock:unlock_phase12
execute if score @s ob_count matches 2100.. unless score @s ob_phase matches 13.. run function oneblock:unlock_phase13
execute if score @s ob_count matches 2450.. unless score @s ob_phase matches 14.. run function oneblock:unlock_phase14
execute if score @s ob_count matches 2850.. unless score @s ob_phase matches 15.. run function oneblock:unlock_phase15
execute if score @s ob_count matches 3300.. unless score @s ob_phase matches 16.. run function oneblock:unlock_phase16
execute if score @s ob_count matches 3800.. unless score @s ob_phase matches 17.. run function oneblock:unlock_phase17
execute if score @s ob_count matches 4350.. unless score @s ob_phase matches 18.. run function oneblock:unlock_phase18
execute if score @s ob_count matches 4950.. unless score @s ob_phase matches 19.. run function oneblock:unlock_phase19
execute if score @s ob_count matches 5600.. unless score @s ob_phase matches 20.. run function oneblock:unlock_phase20
execute if score @s ob_count matches 6300.. unless score @s ob_phase matches 21.. run function oneblock:unlock_phase21
execute if score @s ob_count matches 7050.. unless score @s ob_phase matches 22.. run function oneblock:unlock_phase22
execute if score @s ob_count matches 7850.. unless score @s ob_phase matches 23.. run function oneblock:unlock_phase23
execute if score @s ob_count matches 8700.. unless score @s ob_phase matches 24.. run function oneblock:unlock_phase24
execute if score @s ob_phase matches 1 run function oneblock:phases/phase1
execute if score @s ob_phase matches 2 run function oneblock:phases/phase2
execute if score @s ob_phase matches 3 run function oneblock:phases/phase3
execute if score @s ob_phase matches 4 run function oneblock:phases/phase4
execute if score @s ob_phase matches 5 run function oneblock:phases/phase5
execute if score @s ob_phase matches 6 run function oneblock:phases/phase6
execute if score @s ob_phase matches 7 run function oneblock:phases/phase7
execute if score @s ob_phase matches 8 run function oneblock:phases/phase8
execute if score @s ob_phase matches 9 run function oneblock:phases/phase9
execute if score @s ob_phase matches 10 run function oneblock:phases/phase10
execute if score @s ob_phase matches 11 run function oneblock:phases/phase11
execute if score @s ob_phase matches 12 run function oneblock:phases/phase12
execute if score @s ob_phase matches 13 run function oneblock:phases/phase13
execute if score @s ob_phase matches 14 run function oneblock:phases/phase14
execute if score @s ob_phase matches 15 run function oneblock:phases/phase15
execute if score @s ob_phase matches 16 run function oneblock:phases/phase16
execute if score @s ob_phase matches 17 run function oneblock:phases/phase17
execute if score @s ob_phase matches 18 run function oneblock:phases/phase18
execute if score @s ob_phase matches 19 run function oneblock:phases/phase19
execute if score @s ob_phase matches 20 run function oneblock:phases/phase20
execute if score @s ob_phase matches 21 run function oneblock:phases/phase21
execute if score @s ob_phase matches 22 run function oneblock:phases/phase22
execute if score @s ob_phase matches 23 run function oneblock:phases/phase23
execute if score @s ob_phase matches 24 run function oneblock:phases/phase24
