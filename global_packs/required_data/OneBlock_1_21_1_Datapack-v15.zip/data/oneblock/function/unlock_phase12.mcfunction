scoreboard players set @s ob_phase 12
execute unless score #global_max ob_phase matches 12.. run scoreboard players set #global_max ob_phase 12
advancement grant @a only oneblock:phase12

playsound minecraft:ui.toast.challenge_complete master @a[distance=..64] ~ ~1 ~ 0.9 1.15
playsound minecraft:entity.breeze.wind_burst master @a[distance=..64] ~ ~1 ~ 1.0 0.9
particle minecraft:gust ~ ~1.5 ~ 0.6 1.5 0.6 0.12 70
particle minecraft:end_rod ~ ~2.0 ~ 1.2 2.5 1.2 0.08 40
effect give @a[distance=..32] minecraft:slow_falling 5 0 true

title @a[distance=..64] times 12 65 18
title @a[distance=..64] subtitle {"text":"Solid Metal/Fluix Blocks & Breezes Unlocked!","color":"gray"}
title @a[distance=..64] title {"text":"✦ ACT XII: CYBERNETICS, LUA & LASERS ✦","color":"dark_aqua","bold":true}
tellraw @a[distance=..64] ["",{"text":"\n§8§m--------------------------------------------------\n"},{"text":"  ✦ ACT XII: CYBERNETICS, LUA & LASERS ✦\n","color":"dark_aqua","bold":true},{"text":"  High-velocity wind currents and solid alloy blocks test your engineering. Deploy CC: Tweaked Turtles & Laser Grids!\n","color":"white"},{"text":"  §7(Right-click your Act Field Manual Book or Pedestal anytime for full details!)\n"},{"text":"§8§m--------------------------------------------------"}]
