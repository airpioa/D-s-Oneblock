execute as @e[type=minecraft:item,distance=..8,tag=!ob_core_item] run tag @s add ob_core_item
execute as @e[type=minecraft:item,distance=..64] store result score @s ob_hud run data get entity @s Pos[1]
execute as @e[type=minecraft:item,distance=..64,scores={ob_hud=..58}] run function oneblock:rescue_item
execute if block ~ ~ ~ minecraft:air run function oneblock:respawn_island_block
