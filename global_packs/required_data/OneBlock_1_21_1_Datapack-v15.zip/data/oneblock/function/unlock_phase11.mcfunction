scoreboard players set @s ob_phase 11
execute unless score #global_max ob_phase matches 11.. run scoreboard players set #global_max ob_phase 11
advancement grant @a only oneblock:phase11

playsound minecraft:ui.toast.challenge_complete master @a[distance=..64] ~ ~1 ~ 0.9 1.15
playsound minecraft:entity.ender_dragon.growl master @a[distance=..64] ~ ~1 ~ 1.0 0.9
particle minecraft:dragon_breath ~ ~1.5 ~ 0.6 1.5 0.6 0.12 70
particle minecraft:end_rod ~ ~2.0 ~ 1.2 2.5 1.2 0.08 40
effect give @a[distance=..32] minecraft:slow_falling 5 0 true

title @a[distance=..64] times 12 65 18
title @a[distance=..64] subtitle {"text":"Hardness Tier III! End Stone, Shulkers & Deep Uranium!","color":"gray"}
title @a[distance=..64] title {"text":"✦ ACT XI: NUCLEAR FISSION & END REALMS ✦","color":"dark_purple","bold":true}
tellraw @a[distance=..64] ["",{"text":"\n§8§m--------------------------------------------------\n"},{"text":"  ✦ ACT XI: NUCLEAR FISSION & END REALMS ✦\n","color":"dark_purple","bold":true},{"text":"  Dimensional gravity intensifies. End Stone, Shulkers, and radioactive Uranium veins pierce the surface!\n","color":"white"},{"text":"  §7(Right-click your Act Field Manual Book or Pedestal anytime for full details!)\n"},{"text":"§8§m--------------------------------------------------"}]
