scoreboard players set @s ob_phase 20
execute unless score #global_max ob_phase matches 20.. run scoreboard players set #global_max ob_phase 20
advancement grant @a only oneblock:phase20

playsound minecraft:ui.toast.challenge_complete master @a[distance=..64] ~ ~1 ~ 0.9 1.15
playsound minecraft:entity.elder_guardian.curse master @a[distance=..64] ~ ~1 ~ 1.0 0.9
particle minecraft:bubble_pop ~ ~1.5 ~ 0.6 1.5 0.6 0.12 70
particle minecraft:end_rod ~ ~2.0 ~ 1.2 2.5 1.2 0.08 40
effect give @a[distance=..32] minecraft:slow_falling 5 0 true

title @a[distance=..64] times 12 65 18
title @a[distance=..64] subtitle {"text":"Beacons, Sea Lanterns & Elder Guardians!","color":"gray"}
title @a[distance=..64] title {"text":"✦ ACT XX: ASTRAL STARFORGE ✦","color":"aqua","bold":true}
tellraw @a[distance=..64] ["",{"text":"\n§8§m--------------------------------------------------\n"},{"text":"  ✦ ACT XX: ASTRAL STARFORGE ✦\n","color":"aqua","bold":true},{"text":"  Oceanic and astral energies collide! Prismarine, Beacons, and Elder Guardians test your endgame arsenal!\n","color":"white"},{"text":"  §7(Right-click your Act Field Manual Book or Pedestal anytime for full details!)\n"},{"text":"§8§m--------------------------------------------------"}]
