execute store result score #rng ob_count run random value 1..100
execute if score #rng ob_count matches 1..20 run setblock ~ ~ ~ minecraft:moss_block
execute if score #rng ob_count matches 21..38 run setblock ~ ~ ~ minecraft:oak_log
execute if score #rng ob_count matches 39..54 run setblock ~ ~ ~ minecraft:white_wool
execute if score #rng ob_count matches 55..70 run setblock ~ ~ ~ minecraft:hay_block
execute if score #rng ob_count matches 71..84 run setblock ~ ~ ~ minecraft:bone_block
execute if score #rng ob_count matches 85..88 run summon minecraft:wolf ~ ~1.2 ~
execute if score #rng ob_count matches 89..91 run summon minecraft:cat ~ ~1.2 ~
execute if score #rng ob_count matches 92..93 run summon minecraft:fox ~ ~1.2 ~
execute if score #rng ob_count matches 94..95 run summon minecraft:parrot ~ ~1.5 ~
execute if score #rng ob_count matches 96..96 run summon minecraft:axolotl ~ ~1.2 ~
execute if score #rng ob_count matches 97..100 run setblock ~ ~ ~ minecraft:chest{Items:[{Slot:10b,id:"minecraft:bone",count:16},{Slot:11b,id:"minecraft:cod",count:12},{Slot:12b,id:"minecraft:sweet_berries",count:12},{Slot:13b,id:"minecraft:name_tag",count:4},{Slot:14b,id:"minecraft:lead",count:4},{Slot:15b,id:"minecraft:wolf_armor",count:1}]}
execute if score #rng ob_count matches 85..96 run setblock ~ ~ ~ minecraft:grass_block
