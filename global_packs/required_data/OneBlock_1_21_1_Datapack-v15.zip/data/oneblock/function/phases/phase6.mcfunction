execute store result score #rng ob_count run random value 1..100
execute if score #rng ob_count matches 1..18 run setblock ~ ~ ~ minecraft:deepslate
execute if score #rng ob_count matches 19..30 run setblock ~ ~ ~ create:deepslate_zinc_ore
execute if score #rng ob_count matches 31..44 run setblock ~ ~ ~ minecraft:deepslate_redstone_ore
execute if score #rng ob_count matches 45..56 run setblock ~ ~ ~ minecraft:obsidian
execute if score #rng ob_count matches 57..70 run setblock ~ ~ ~ minecraft:netherrack
execute if score #rng ob_count matches 71..82 run setblock ~ ~ ~ minecraft:quartz_ore
execute if score #rng ob_count matches 83..90 run setblock ~ ~ ~ create:scoria
execute if score #rng ob_count matches 91..93 run summon minecraft:blaze ~ ~1.2 ~
execute if score #rng ob_count matches 94..96 run summon minecraft:zombified_piglin ~ ~1.2 ~
execute if score #rng ob_count matches 97..100 run setblock ~ ~ ~ minecraft:chest{Items:[{Slot:10b,id:"create:brass_ingot",count:8},{Slot:11b,id:"minecraft:blaze_rod",count:3},{Slot:12b,id:"minecraft:obsidian",count:6},{Slot:13b,id:"minecraft:flint_and_steel",count:1},{Slot:14b,id:"minecraft:nether_wart",count:4},{Slot:15b,id:"minecraft:golden_apple",count:2}]}
execute if score #rng ob_count matches 91..96 run setblock ~ ~ ~ minecraft:magma_block
