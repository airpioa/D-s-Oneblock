execute store result score #rng ob_count run random value 1..100
execute if score #rng ob_count matches 1..25 run setblock ~ ~ ~ minecraft:grass_block
execute if score #rng ob_count matches 26..40 run setblock ~ ~ ~ minecraft:dirt
execute if score #rng ob_count matches 41..55 run setblock ~ ~ ~ minecraft:oak_log
execute if score #rng ob_count matches 56..66 run setblock ~ ~ ~ minecraft:birch_log
execute if score #rng ob_count matches 67..81 run setblock ~ ~ ~ minecraft:andesite
execute if score #rng ob_count matches 82..90 run setblock ~ ~ ~ minecraft:clay
execute if score #rng ob_count matches 91..96 run setblock ~ ~ ~ minecraft:sand
execute if score #rng ob_count matches 97..100 run setblock ~ ~ ~ minecraft:chest{Items:[{Slot:10b,id:"minecraft:oak_sapling",count:2},{Slot:11b,id:"minecraft:kelp",count:6},{Slot:12b,id:"minecraft:apple",count:4},{Slot:13b,id:"minecraft:wheat_seeds",count:4},{Slot:14b,id:"minecraft:potato",count:2},{Slot:15b,id:"minecraft:gravel",count:8}]}
