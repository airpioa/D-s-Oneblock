execute store result score #rng ob_count run random value 1..100
execute if score #rng ob_count matches 1..28 run setblock ~ ~ ~ minecraft:oxidized_copper_bulb
execute if score #rng ob_count matches 29..56 run setblock ~ ~ ~ minecraft:chiseled_tuff_bricks
execute if score #rng ob_count matches 57..82 run setblock ~ ~ ~ minecraft:waxed_oxidized_copper
execute if score #rng ob_count matches 83..90 run setblock ~ ~ ~ minecraft:heavy_core
execute if score #rng ob_count matches 91..94 run summon minecraft:breeze ~ ~1.2 ~
execute if score #rng ob_count matches 95..100 run setblock ~ ~ ~ minecraft:chest{Items:[{Slot:10b,id:"minecraft:heavy_core",count:1},{Slot:11b,id:"minecraft:breeze_rod",count:8},{Slot:12b,id:"minecraft:ominous_trial_key",count:2},{Slot:13b,id:"kubejs:architect_token",count:2},{Slot:14b,id:"minecraft:wind_charge",count:16},{Slot:15b,id:"minecraft:enchanted_golden_apple",count:2}]}
execute if score #rng ob_count matches 91..94 run setblock ~ ~ ~ minecraft:gilded_blackstone
