execute store result score #rng ob_count run random value 1..100
execute if score #rng ob_count matches 1..24 run setblock ~ ~ ~ create:railway_casing
execute if score #rng ob_count matches 25..46 run setblock ~ ~ ~ create:brass_casing
execute if score #rng ob_count matches 47..68 run setblock ~ ~ ~ minecraft:copper_block
execute if score #rng ob_count matches 69..86 run setblock ~ ~ ~ minecraft:deepslate_emerald_ore
execute if score #rng ob_count matches 87..90 run setblock ~ ~ ~ create:andesite_casing
execute if score #rng ob_count matches 91..93 run summon minecraft:villager ~ ~1.2 ~
execute if score #rng ob_count matches 94..95 run summon minecraft:iron_golem ~ ~1.2 ~
execute if score #rng ob_count matches 96..100 run setblock ~ ~ ~ minecraft:chest{Items:[{Slot:10b,id:"create:track",count:64},{Slot:11b,id:"create:controls",count:1},{Slot:12b,id:"create:railway_casing",count:4},{Slot:13b,id:"create:schedule",count:2},{Slot:14b,id:"minecraft:emerald",count:8},{Slot:15b,id:"create:brass_ingot",count:8}]}
execute if score #rng ob_count matches 91..95 run setblock ~ ~ ~ minecraft:emerald_block
