execute store result score #rng ob_count run random value 1..100
execute if score #rng ob_count matches 1..30 run setblock ~ ~ ~ minecraft:reinforced_deepslate
execute if score #rng ob_count matches 31..55 run setblock ~ ~ ~ minecraft:ancient_debris
execute if score #rng ob_count matches 56..78 run setblock ~ ~ ~ mekanism:block_refined_obsidian
execute if score #rng ob_count matches 79..90 run setblock ~ ~ ~ minecraft:netherite_block
execute if score #rng ob_count matches 91..94 run summon minecraft:piglin_brute ~ ~1.2 ~
execute if score #rng ob_count matches 95..100 run setblock ~ ~ ~ minecraft:chest{Items:[{Slot:10b,id:"minecraft:ancient_debris",count:4},{Slot:11b,id:"minecraft:netherite_ingot",count:2},{Slot:12b,id:"minecraft:echo_shard",count:4},{Slot:13b,id:"kubejs:architect_token",count:1},{Slot:14b,id:"create:precision_mechanism",count:4},{Slot:15b,id:"minecraft:enchanted_golden_apple",count:1}]}
execute if score #rng ob_count matches 91..94 run setblock ~ ~ ~ minecraft:gilded_blackstone
