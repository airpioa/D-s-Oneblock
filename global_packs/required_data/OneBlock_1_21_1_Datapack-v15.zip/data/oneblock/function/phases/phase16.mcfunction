execute store result score #rng ob_count run random value 1..100
execute if score #rng ob_count matches 1..24 run setblock ~ ~ ~ mekanism:block_uranium
execute if score #rng ob_count matches 25..48 run setblock ~ ~ ~ mekanism:block_fluorite
execute if score #rng ob_count matches 49..72 run setblock ~ ~ ~ minecraft:crying_obsidian
execute if score #rng ob_count matches 73..90 run setblock ~ ~ ~ minecraft:netherite_block
execute if score #rng ob_count matches 91..94 run summon minecraft:wither_skeleton ~ ~1.2 ~
execute if score #rng ob_count matches 95..100 run setblock ~ ~ ~ minecraft:chest{Items:[{Slot:10b,id:"mekanism:pellet_polonium",count:4},{Slot:11b,id:"mekanism:pellet_antimatter",count:1},{Slot:12b,id:"minecraft:nether_star",count:1},{Slot:13b,id:"kubejs:architect_token",count:1},{Slot:14b,id:"ae2:singularity",count:4},{Slot:15b,id:"minecraft:enchanted_golden_apple",count:2}]}
execute if score #rng ob_count matches 91..94 run setblock ~ ~ ~ minecraft:obsidian
