execute store result score #rng ob_count run random value 1..100
execute if score #rng ob_count matches 1..20 run setblock ~ ~ ~ minecraft:bookshelf
execute if score #rng ob_count matches 21..38 run setblock ~ ~ ~ minecraft:deepslate_lapis_ore
execute if score #rng ob_count matches 39..56 run setblock ~ ~ ~ minecraft:sculk
execute if score #rng ob_count matches 57..72 run setblock ~ ~ ~ minecraft:amethyst_block
execute if score #rng ob_count matches 73..87 run setblock ~ ~ ~ minecraft:suspicious_sand
execute if score #rng ob_count matches 88..90 run summon minecraft:allay ~ ~1.5 ~
execute if score #rng ob_count matches 91..92 run summon minecraft:sniffer ~ ~1.2 ~
execute if score #rng ob_count matches 93..94 run summon minecraft:armadillo ~ ~1.2 ~
execute if score #rng ob_count matches 95..95 run summon minecraft:witch ~ ~1.2 ~
execute if score #rng ob_count matches 96..100 run setblock ~ ~ ~ minecraft:chest{Items:[{Slot:10b,id:"minecraft:experience_bottle",count:16},{Slot:11b,id:"minecraft:brush",count:1},{Slot:12b,id:"minecraft:book",count:8},{Slot:13b,id:"create:experience_nugget",count:16},{Slot:14b,id:"minecraft:echo_shard",count:2},{Slot:15b,id:"minecraft:totem_of_undying",count:1}]}
execute if score #rng ob_count matches 88..95 run setblock ~ ~ ~ minecraft:moss_block
