execute store result score #rng ob_count run random value 1..100
execute if score #rng ob_count matches 1..20 run setblock ~ ~ ~ minecraft:ancient_debris
execute if score #rng ob_count matches 21..38 run setblock ~ ~ ~ minecraft:netherite_block
execute if score #rng ob_count matches 39..54 run setblock ~ ~ ~ minecraft:reinforced_deepslate
execute if score #rng ob_count matches 55..70 run setblock ~ ~ ~ create:brass_block
execute if score #rng ob_count matches 71..84 run setblock ~ ~ ~ mekanism:block_osmium
execute if score #rng ob_count matches 85..90 run setblock ~ ~ ~ minecraft:heavy_core
execute if score #rng ob_count matches 91..94 run summon minecraft:iron_golem ~ ~1.2 ~
execute if score #rng ob_count matches 95..100 run setblock ~ ~ ~ minecraft:chest{Items:[{Slot:10b,id:"minecraft:nether_star",count:2},{Slot:11b,id:"mekanism:alloy_atomic",count:8},{Slot:12b,id:"create:precision_mechanism",count:6},{Slot:13b,id:"minecraft:nether_star",count:2},{Slot:14b,id:"minecraft:enchanted_golden_apple",count:2},{Slot:15b,id:"kubejs:architect_token",count:3}]}
execute if score #rng ob_count matches 91..94 run setblock ~ ~ ~ minecraft:beacon
