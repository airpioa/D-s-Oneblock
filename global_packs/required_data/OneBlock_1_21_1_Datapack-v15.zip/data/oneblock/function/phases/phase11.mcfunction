execute store result score #rng ob_count run random value 1..100
execute if score #rng ob_count matches 1..26 run setblock ~ ~ ~ minecraft:end_stone
execute if score #rng ob_count matches 27..44 run setblock ~ ~ ~ mekanism:deepslate_uranium_ore
execute if score #rng ob_count matches 45..62 run setblock ~ ~ ~ minecraft:deepslate_emerald_ore
execute if score #rng ob_count matches 63..78 run setblock ~ ~ ~ minecraft:deepslate_diamond_ore
execute if score #rng ob_count matches 79..90 run setblock ~ ~ ~ minecraft:crying_obsidian
execute if score #rng ob_count matches 91..96 run summon minecraft:shulker ~ ~1.2 ~
execute if score #rng ob_count matches 97..100 run setblock ~ ~ ~ minecraft:chest{Items:[{Slot:10b,id:"minecraft:ender_pearl",count:8},{Slot:11b,id:"mekanism:alloy_infused",count:8},{Slot:12b,id:"mekanism:alloy_reinforced",count:4},{Slot:13b,id:"minecraft:shulker_shell",count:2},{Slot:14b,id:"minecraft:phantom_membrane",count:4},{Slot:15b,id:"minecraft:chorus_fruit",count:4}]}
execute if score #rng ob_count matches 91..96 run setblock ~ ~ ~ minecraft:purpur_block
