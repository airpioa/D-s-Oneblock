execute store result score #rng ob_count run random value 1..100
execute if score #rng ob_count matches 1..25 run setblock ~ ~ ~ minecraft:sea_lantern
execute if score #rng ob_count matches 26..50 run setblock ~ ~ ~ minecraft:prismarine_bricks
execute if score #rng ob_count matches 51..75 run setblock ~ ~ ~ minecraft:beacon
execute if score #rng ob_count matches 76..90 run setblock ~ ~ ~ mekanism:block_uranium
execute if score #rng ob_count matches 91..93 run summon minecraft:elder_guardian ~ ~1.5 ~
execute if score #rng ob_count matches 94..100 run setblock ~ ~ ~ minecraft:chest{Items:[{Slot:10b,id:"minecraft:heart_of_the_sea",count:2},{Slot:11b,id:"minecraft:nautilus_shell",count:8},{Slot:12b,id:"minecraft:nether_star",count:1},{Slot:13b,id:"kubejs:architect_token",count:2},{Slot:14b,id:"minecraft:sponge",count:8},{Slot:15b,id:"minecraft:enchanted_golden_apple",count:2}]}
execute if score #rng ob_count matches 91..93 run setblock ~ ~ ~ minecraft:dark_prismarine
