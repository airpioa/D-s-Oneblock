execute store result score #rng ob_count run random value 1..100
execute if score #rng ob_count matches 1..28 run setblock ~ ~ ~ minecraft:reinforced_deepslate
execute if score #rng ob_count matches 29..56 run setblock ~ ~ ~ minecraft:sculk_shrieker
execute if score #rng ob_count matches 57..82 run setblock ~ ~ ~ minecraft:netherite_block
execute if score #rng ob_count matches 83..91 run setblock ~ ~ ~ mekanism:block_refined_obsidian
execute if score #rng ob_count matches 92..94 run summon minecraft:wither_skeleton ~ ~1.2 ~
execute if score #rng ob_count matches 95..100 run setblock ~ ~ ~ minecraft:chest{Items:[{Slot:10b,id:"minecraft:echo_shard",count:8},{Slot:11b,id:"mekanism:pellet_antimatter",count:2},{Slot:12b,id:"minecraft:nether_star",count:2},{Slot:13b,id:"kubejs:architect_token",count:3},{Slot:14b,id:"kubejs:mystery_crate_tech",count:2},{Slot:15b,id:"minecraft:totem_of_undying",count:1}]}
execute if score #rng ob_count matches 92..94 run setblock ~ ~ ~ minecraft:crying_obsidian
