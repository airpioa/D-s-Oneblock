execute store result score #rng ob_count run random value 1..100
execute if score #rng ob_count matches 1..20 run setblock ~ ~ ~ minecraft:moss_block
execute if score #rng ob_count matches 21..40 run setblock ~ ~ ~ minecraft:cherry_log
execute if score #rng ob_count matches 41..60 run setblock ~ ~ ~ minecraft:podzol
execute if score #rng ob_count matches 61..78 run setblock ~ ~ ~ minecraft:mycelium
execute if score #rng ob_count matches 79..87 run setblock ~ ~ ~ minecraft:packed_ice
execute if score #rng ob_count matches 88..90 run summon minecraft:panda ~ ~1.2 ~
execute if score #rng ob_count matches 91..92 run summon minecraft:frog ~ ~1.2 ~
execute if score #rng ob_count matches 93..94 run summon minecraft:camel ~ ~1.2 ~
execute if score #rng ob_count matches 95..100 run setblock ~ ~ ~ minecraft:chest{Items:[{Slot:10b,id:"minecraft:cherry_sapling",count:4},{Slot:11b,id:"minecraft:mangrove_propagule",count:4},{Slot:12b,id:"minecraft:bamboo",count:8},{Slot:13b,id:"minecraft:spore_blossom",count:2},{Slot:14b,id:"minecraft:bee_nest",count:1},{Slot:15b,id:"kubejs:biome_prism",count:2}]}
execute if score #rng ob_count matches 88..94 run setblock ~ ~ ~ minecraft:moss_block
