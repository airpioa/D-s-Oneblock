execute store result score #rng ob_count run random value 1..100
execute if score #rng ob_count matches 1..24 run setblock ~ ~ ~ minecraft:diamond_block
execute if score #rng ob_count matches 25..46 run setblock ~ ~ ~ minecraft:emerald_block
execute if score #rng ob_count matches 47..68 run setblock ~ ~ ~ mekanism:block_refined_obsidian
execute if score #rng ob_count matches 69..88 run setblock ~ ~ ~ ae2:fluix_block
execute if score #rng ob_count matches 89..92 run setblock ~ ~ ~ minecraft:ancient_debris
execute if score #rng ob_count matches 93..95 run summon minecraft:ravager ~ ~1.2 ~
execute if score #rng ob_count matches 96..100 run setblock ~ ~ ~ minecraft:chest{Items:[{Slot:10b,id:"mekanism:pellet_polonium",count:2},{Slot:11b,id:"mekanism:pellet_plutonium",count:2},{Slot:12b,id:"ae2:singularity",count:2},{Slot:13b,id:"minecraft:netherite_scrap",count:4},{Slot:14b,id:"create:precision_mechanism",count:4},{Slot:15b,id:"minecraft:enchanted_golden_apple",count:1}]}
execute if score #rng ob_count matches 93..95 run setblock ~ ~ ~ minecraft:crying_obsidian
