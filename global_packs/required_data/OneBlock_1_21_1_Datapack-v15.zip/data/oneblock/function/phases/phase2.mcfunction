execute store result score #rng ob_count run random value 1..100
execute if score #rng ob_count matches 1..20 run setblock ~ ~ ~ minecraft:stone
execute if score #rng ob_count matches 21..33 run setblock ~ ~ ~ minecraft:cobblestone
execute if score #rng ob_count matches 34..46 run setblock ~ ~ ~ minecraft:coal_ore
execute if score #rng ob_count matches 47..60 run setblock ~ ~ ~ minecraft:copper_ore
execute if score #rng ob_count matches 61..74 run setblock ~ ~ ~ create:zinc_ore
execute if score #rng ob_count matches 75..85 run setblock ~ ~ ~ minecraft:iron_ore
execute if score #rng ob_count matches 86..90 run setblock ~ ~ ~ create:limestone
execute if score #rng ob_count matches 91..93 run summon minecraft:sheep ~ ~1.2 ~
execute if score #rng ob_count matches 94..95 run summon minecraft:chicken ~ ~1.2 ~
execute if score #rng ob_count matches 96..96 run summon minecraft:zombie ~ ~1.2 ~
execute if score #rng ob_count matches 97..100 run setblock ~ ~ ~ minecraft:chest{Items:[{Slot:11b,id:"minecraft:water_bucket",count:1},{Slot:12b,id:"minecraft:lava_bucket",count:1},{Slot:13b,id:"create:andesite_alloy",count:12},{Slot:14b,id:"create:cogwheel",count:4},{Slot:15b,id:"minecraft:torch",count:12}]}
execute if score #rng ob_count matches 91..96 run setblock ~ ~ ~ minecraft:moss_block
