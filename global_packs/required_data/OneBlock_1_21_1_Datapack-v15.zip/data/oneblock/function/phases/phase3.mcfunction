execute store result score #rng ob_count run random value 1..100
execute if score #rng ob_count matches 1..18 run setblock ~ ~ ~ farmersdelight:rich_soil
execute if score #rng ob_count matches 19..32 run setblock ~ ~ ~ minecraft:clay
execute if score #rng ob_count matches 33..46 run setblock ~ ~ ~ minecraft:rooted_dirt
execute if score #rng ob_count matches 47..60 run setblock ~ ~ ~ minecraft:oak_log
execute if score #rng ob_count matches 61..74 run setblock ~ ~ ~ minecraft:iron_ore
execute if score #rng ob_count matches 75..86 run setblock ~ ~ ~ minecraft:copper_ore
execute if score #rng ob_count matches 87..89 run summon minecraft:cow ~ ~1.2 ~
execute if score #rng ob_count matches 90..92 run summon minecraft:pig ~ ~1.2 ~
execute if score #rng ob_count matches 93..94 run summon minecraft:bee ~ ~1.5 ~
execute if score #rng ob_count matches 95..95 run summon minecraft:skeleton ~ ~1.2 ~
execute if score #rng ob_count matches 96..100 run setblock ~ ~ ~ minecraft:chest{Items:[{Slot:10b,id:"farmersdelight:tomato_seeds",count:4},{Slot:11b,id:"farmersdelight:cabbage_seeds",count:4},{Slot:12b,id:"farmersdelight:onion",count:4},{Slot:13b,id:"vinery:red_grape_seeds",count:4},{Slot:14b,id:"herbalbrews:tea_blossom",count:4},{Slot:15b,id:"minecraft:bone_meal",count:16}]}
execute if score #rng ob_count matches 87..95 run setblock ~ ~ ~ minecraft:hay_block
