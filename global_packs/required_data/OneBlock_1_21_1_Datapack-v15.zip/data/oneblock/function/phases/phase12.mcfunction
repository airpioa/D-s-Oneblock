execute store result score #rng ob_count run random value 1..100
execute if score #rng ob_count matches 1..20 run setblock ~ ~ ~ minecraft:redstone_block
execute if score #rng ob_count matches 21..40 run setblock ~ ~ ~ mekanism:block_osmium
execute if score #rng ob_count matches 41..58 run setblock ~ ~ ~ ae2:fluix_block
execute if score #rng ob_count matches 59..76 run setblock ~ ~ ~ minecraft:obsidian
execute if score #rng ob_count matches 77..90 run setblock ~ ~ ~ minecraft:copper_bulb
execute if score #rng ob_count matches 91..94 run summon minecraft:breeze ~ ~1.2 ~
execute if score #rng ob_count matches 95..100 run setblock ~ ~ ~ minecraft:chest{Items:[{Slot:10b,id:"mekanism:alloy_atomic",count:4},{Slot:11b,id:"mekanism:teleportation_core",count:1},{Slot:12b,id:"ae2:logic_processor",count:8},{Slot:13b,id:"ae2:engineering_processor",count:8},{Slot:14b,id:"minecraft:repeater",count:8},{Slot:15b,id:"minecraft:comparator",count:8}]}
execute if score #rng ob_count matches 91..94 run setblock ~ ~ ~ minecraft:chiseled_tuff
