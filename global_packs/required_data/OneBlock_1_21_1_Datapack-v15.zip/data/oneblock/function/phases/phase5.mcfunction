execute store result score #rng ob_count run random value 1..100
execute if score #rng ob_count matches 1..16 run setblock ~ ~ ~ mekanism:osmium_ore
execute if score #rng ob_count matches 17..30 run setblock ~ ~ ~ mekanism:tin_ore
execute if score #rng ob_count matches 31..44 run setblock ~ ~ ~ mekanism:lead_ore
execute if score #rng ob_count matches 45..56 run setblock ~ ~ ~ mekanism:fluorite_ore
execute if score #rng ob_count matches 57..68 run setblock ~ ~ ~ mekanism:uranium_ore
execute if score #rng ob_count matches 69..80 run setblock ~ ~ ~ minecraft:gold_ore
execute if score #rng ob_count matches 81..90 run setblock ~ ~ ~ minecraft:deepslate_iron_ore
execute if score #rng ob_count matches 91..93 run summon minecraft:creeper ~ ~1.2 ~
execute if score #rng ob_count matches 94..96 run summon minecraft:spider ~ ~1.2 ~
execute if score #rng ob_count matches 97..100 run setblock ~ ~ ~ minecraft:chest{Items:[{Slot:10b,id:"mekanism:ingot_osmium",count:8},{Slot:11b,id:"mekanism:ingot_tin",count:6},{Slot:12b,id:"mekanism:ingot_lead",count:6},{Slot:13b,id:"mekanism:fluorite_gem",count:8},{Slot:14b,id:"minecraft:redstone",count:12},{Slot:15b,id:"minecraft:lava_bucket",count:1}]}
execute if score #rng ob_count matches 91..96 run setblock ~ ~ ~ minecraft:cobbled_deepslate
