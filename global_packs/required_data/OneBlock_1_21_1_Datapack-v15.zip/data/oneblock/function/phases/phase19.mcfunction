execute store result score #rng ob_count run random value 1..100
execute if score #rng ob_count matches 1..25 run setblock ~ ~ ~ minecraft:diamond_block
execute if score #rng ob_count matches 26..50 run setblock ~ ~ ~ minecraft:emerald_block
execute if score #rng ob_count matches 51..75 run setblock ~ ~ ~ minecraft:netherite_block
execute if score #rng ob_count matches 76..90 run setblock ~ ~ ~ minecraft:reinforced_deepslate
execute if score #rng ob_count matches 91..94 run summon minecraft:phantom ~ ~2.5 ~
execute if score #rng ob_count matches 95..100 run setblock ~ ~ ~ minecraft:chest{Items:[{Slot:10b,id:"minecraft:netherite_ingot",count:4},{Slot:11b,id:"mekanism:pellet_antimatter",count:2},{Slot:12b,id:"minecraft:dragon_breath",count:4},{Slot:13b,id:"kubejs:architect_token",count:2},{Slot:14b,id:"minecraft:nether_star",count:1},{Slot:15b,id:"minecraft:enchanted_golden_apple",count:2}]}
execute if score #rng ob_count matches 91..94 run setblock ~ ~ ~ minecraft:purpur_pillar
