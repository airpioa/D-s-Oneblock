execute store result score #rng ob_count run random value 1..100
execute if score #rng ob_count matches 1..22 run setblock ~ ~ ~ create:andesite_casing
execute if score #rng ob_count matches 23..44 run setblock ~ ~ ~ create:brass_casing
execute if score #rng ob_count matches 45..66 run setblock ~ ~ ~ minecraft:white_wool
execute if score #rng ob_count matches 67..86 run setblock ~ ~ ~ minecraft:copper_block
execute if score #rng ob_count matches 87..94 run setblock ~ ~ ~ minecraft:obsidian
execute if score #rng ob_count matches 95..100 run setblock ~ ~ ~ minecraft:chest{Items:[{Slot:10b,id:"waystones:waystone",count:2},{Slot:11b,id:"waystones:warp_stone",count:1},{Slot:12b,id:"immersive_aircraft:engine",count:1},{Slot:13b,id:"create:propeller",count:2},{Slot:14b,id:"create:white_sail",count:16},{Slot:15b,id:"minecraft:ender_pearl",count:8}]}
