execute store result score #rng ob_count run random value 1..100
execute if score #rng ob_count matches 1..25 run setblock ~ ~ ~ minecraft:mycelium
execute if score #rng ob_count matches 26..50 run setblock ~ ~ ~ minecraft:shroomlight
execute if score #rng ob_count matches 51..75 run setblock ~ ~ ~ minecraft:honeycomb_block
execute if score #rng ob_count matches 76..86 run setblock ~ ~ ~ minecraft:gold_block
execute if score #rng ob_count matches 87..89 run summon minecraft:mooshroom ~ ~1.2 ~
execute if score #rng ob_count matches 90..91 run summon minecraft:strider ~ ~1.2 ~
execute if score #rng ob_count matches 92..93 run summon minecraft:glow_squid ~ ~1.5 ~
execute if score #rng ob_count matches 94..94 run summon minecraft:llama ~ ~1.2 ~
execute if score #rng ob_count matches 95..100 run setblock ~ ~ ~ minecraft:chest{Items:[{Slot:10b,id:"minecraft:enchanted_golden_apple",count:2},{Slot:11b,id:"minecraft:golden_carrot",count:16},{Slot:12b,id:"minecraft:saddle",count:2},{Slot:13b,id:"minecraft:diamond_horse_armor",count:1},{Slot:14b,id:"kubejs:architect_token",count:2},{Slot:15b,id:"minecraft:totem_of_undying",count:1}]}
execute if score #rng ob_count matches 87..94 run setblock ~ ~ ~ minecraft:moss_block
