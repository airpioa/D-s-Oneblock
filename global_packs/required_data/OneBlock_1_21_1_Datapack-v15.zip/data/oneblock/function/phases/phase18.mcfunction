execute store result score #rng ob_count run random value 1..100
execute if score #rng ob_count matches 1..26 run setblock ~ ~ ~ minecraft:reinforced_deepslate
execute if score #rng ob_count matches 27..52 run setblock ~ ~ ~ ae2:fluix_block
execute if score #rng ob_count matches 53..76 run setblock ~ ~ ~ mekanism:block_osmium
execute if score #rng ob_count matches 77..92 run setblock ~ ~ ~ minecraft:crying_obsidian
execute if score #rng ob_count matches 93..94 run tellraw @a[distance=..32] ["",{"text":"[DANGER — VOID RIFT] ","color":"dark_aqua","bold":true},{"text":"A Warden has emerged from the Anomaly Pedestal!","color":"red"}]
execute if score #rng ob_count matches 93..94 run summon minecraft:warden ~ ~1.2 ~
execute if score #rng ob_count matches 95..100 run setblock ~ ~ ~ minecraft:chest{Items:[{Slot:10b,id:"mekanism:teleportation_core",count:2},{Slot:11b,id:"ae2:singularity",count:4},{Slot:12b,id:"minecraft:nether_star",count:1},{Slot:13b,id:"kubejs:mystery_crate_tech",count:1},{Slot:14b,id:"minecraft:sculk_catalyst",count:2},{Slot:15b,id:"minecraft:totem_of_undying",count:1}]}
execute if score #rng ob_count matches 93..94 run setblock ~ ~ ~ minecraft:sculk_catalyst
