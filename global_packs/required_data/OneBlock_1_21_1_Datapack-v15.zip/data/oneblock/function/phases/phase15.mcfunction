execute store result score #rng ob_count run random value 1..100
execute if score #rng ob_count matches 1..24 run setblock ~ ~ ~ create:brass_block
execute if score #rng ob_count matches 25..48 run setblock ~ ~ ~ minecraft:quartz_block
execute if score #rng ob_count matches 49..72 run setblock ~ ~ ~ minecraft:emerald_block
execute if score #rng ob_count matches 73..90 run setblock ~ ~ ~ minecraft:gold_block
execute if score #rng ob_count matches 91..94 run summon minecraft:evoker ~ ~1.2 ~
execute if score #rng ob_count matches 95..100 run setblock ~ ~ ~ minecraft:chest{Items:[{Slot:10b,id:"chipped:carpenters_table",count:1},{Slot:11b,id:"chipped:mason_table",count:1},{Slot:12b,id:"create:brass_block",count:4},{Slot:13b,id:"minecraft:emerald_block",count:2},{Slot:14b,id:"kubejs:sky_token",count:3},{Slot:15b,id:"minecraft:golden_apple",count:4}]}
execute if score #rng ob_count matches 91..94 run setblock ~ ~ ~ minecraft:obsidian
