execute store result score #rng ob_count run random value 1..100
execute if score #rng ob_count matches 1..20 run setblock ~ ~ ~ ae2:sky_stone_block
execute if score #rng ob_count matches 21..40 run setblock ~ ~ ~ ae2:quartz_ore
execute if score #rng ob_count matches 41..52 run setblock ~ ~ ~ ae2:flawed_budding_quartz
execute if score #rng ob_count matches 53..68 run setblock ~ ~ ~ minecraft:deepslate_diamond_ore
execute if score #rng ob_count matches 69..82 run setblock ~ ~ ~ minecraft:obsidian
execute if score #rng ob_count matches 83..90 run setblock ~ ~ ~ minecraft:amethyst_block
execute if score #rng ob_count matches 91..95 run summon minecraft:enderman ~ ~1.2 ~
execute if score #rng ob_count matches 96..100 run setblock ~ ~ ~ minecraft:chest{Items:[{Slot:10b,id:"ae2:certus_quartz_crystal",count:12},{Slot:11b,id:"ae2:calculation_processor_press",count:1},{Slot:12b,id:"ae2:engineering_processor_press",count:1},{Slot:13b,id:"ae2:logic_processor_press",count:1},{Slot:14b,id:"ae2:silicon_press",count:1},{Slot:15b,id:"create:precision_mechanism",count:2}]}
execute if score #rng ob_count matches 91..95 run setblock ~ ~ ~ ae2:sky_stone_block
