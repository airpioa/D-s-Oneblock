scoreboard players set @s ob_phase 16
execute unless score #global_max ob_phase matches 16.. run scoreboard players set #global_max ob_phase 16
advancement grant @a only oneblock:phase16

playsound minecraft:ui.toast.challenge_complete master @a[distance=..64] ~ ~1 ~ 0.9 1.15
playsound minecraft:entity.wither.spawn master @a[distance=..64] ~ ~1 ~ 1.0 0.9
particle minecraft:crimson_spore ~ ~1.5 ~ 0.6 1.5 0.6 0.12 70
particle minecraft:end_rod ~ ~2.0 ~ 1.2 2.5 1.2 0.08 40
effect give @a[distance=..32] minecraft:slow_falling 5 0 true

title @a[distance=..64] times 12 65 18
title @a[distance=..64] subtitle {"text":"Hardness Tier IV! Solid Netherite, Uranium & Wither Skeletons!","color":"gray"}
title @a[distance=..64] title {"text":"✦ ACT XVI: STELLAR FUSION & VOID GATES ✦","color":"red","bold":true}
tellraw @a[distance=..64] ["",{"text":"\n§8§m--------------------------------------------------\n"},{"text":"  ✦ ACT XVI: STELLAR FUSION & VOID GATES ✦\n","color":"red","bold":true},{"text":"  Abyssal density locks the core! Solid Netherite and Uranium blocks demand industrial automation!\n","color":"white"},{"text":"  §7(Right-click your Act Field Manual Book or Pedestal anytime for full details!)\n"},{"text":"§8§m--------------------------------------------------"}]
