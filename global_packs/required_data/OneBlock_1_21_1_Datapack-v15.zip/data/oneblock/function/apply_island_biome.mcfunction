execute store result score #b_rng ob_id run random value 1..6
execute if score #b_rng ob_id matches 1 run fillbiome ~-48 -64 ~-48 ~48 319 ~48 minecraft:meadow
execute if score #b_rng ob_id matches 2 run fillbiome ~-48 -64 ~-48 ~48 319 ~48 minecraft:cherry_grove
execute if score #b_rng ob_id matches 3 run fillbiome ~-48 -64 ~-48 ~48 319 ~48 minecraft:flower_forest
execute if score #b_rng ob_id matches 4 run fillbiome ~-48 -64 ~-48 ~48 319 ~48 minecraft:bamboo_jungle
execute if score #b_rng ob_id matches 5 run fillbiome ~-48 -64 ~-48 ~48 319 ~48 minecraft:taiga
execute if score #b_rng ob_id matches 6 run fillbiome ~-48 -64 ~-48 ~48 319 ~48 minecraft:savanna
