scoreboard players set @s ob_phase 8
execute unless score #global_max ob_phase matches 8.. run scoreboard players set #global_max ob_phase 8
advancement grant @a only oneblock:phase8

playsound minecraft:ui.toast.challenge_complete master @a[distance=..64] ~ ~1 ~ 0.9 1.15
playsound minecraft:entity.phantom.flap master @a[distance=..64] ~ ~1 ~ 1.0 0.9
particle minecraft:cloud ~ ~1.5 ~ 0.6 1.5 0.6 0.12 70
particle minecraft:end_rod ~ ~2.0 ~ 1.2 2.5 1.2 0.08 40
effect give @a[distance=..32] minecraft:slow_falling 5 0 true

title @a[distance=..64] times 12 65 18
title @a[distance=..64] subtitle {"text":"Immersive Aircraft, Aeronautics & Waystones Unlocked!","color":"gray"}
title @a[distance=..64] title {"text":"✦ ACT VIII: SKY-SHIPS & WAYSTONE PORTALS ✦","color":"aqua","bold":true}
tellraw @a[distance=..64] ["",{"text":"\n§8§m--------------------------------------------------\n"},{"text":"  ✦ ACT VIII: SKY-SHIPS & WAYSTONE PORTALS ✦\n","color":"aqua","bold":true},{"text":"  Take to the skies! Craft Immersive Aircraft engines, Create Aeronautics airships, or Waystones to cross the 1,024m void!\n","color":"white"},{"text":"  §7(Right-click your Act Field Manual Book or Pedestal anytime for full details!)\n"},{"text":"§8§m--------------------------------------------------"}]
