scoreboard players set @s ob_phase 23
execute unless score #global_max ob_phase matches 23.. run scoreboard players set #global_max ob_phase 23
advancement grant @a only oneblock:phase23

playsound minecraft:ui.toast.challenge_complete master @a[distance=..64] ~ ~1 ~ 0.9 1.15
playsound minecraft:entity.ender_dragon.death master @a[distance=..64] ~ ~1 ~ 1.0 0.9
particle minecraft:reverse_portal ~ ~1.5 ~ 0.6 1.5 0.6 0.12 70
particle minecraft:end_rod ~ ~2.0 ~ 1.2 2.5 1.2 0.08 40
effect give @a[distance=..32] minecraft:slow_falling 5 0 true

title @a[distance=..64] times 12 65 18
title @a[distance=..64] subtitle {"text":"Sculk Shriekers, Netherite Vaults & Antimatter Pellets!","color":"gray"}
title @a[distance=..64] title {"text":"✦ ACT XXIII: VOID SOVEREIGN ECLIPSE ✦","color":"dark_purple","bold":true}
tellraw @a[distance=..64] ["",{"text":"\n§8§m--------------------------------------------------\n"},{"text":"  ✦ ACT XXIII: VOID SOVEREIGN ECLIPSE ✦\n","color":"dark_purple","bold":true},{"text":"  Total Void Eclipse! The pedestal channels pure singularity energy—only one Act remains before ascension!\n","color":"white"},{"text":"  §7(Right-click your Act Field Manual Book or Pedestal anytime for full details!)\n"},{"text":"§8§m--------------------------------------------------"}]
