scoreboard players set @s ob_phase 18
execute unless score #global_max ob_phase matches 18.. run scoreboard players set #global_max ob_phase 18
advancement grant @a only oneblock:phase18

playsound minecraft:ui.toast.challenge_complete master @a[distance=..64] ~ ~1 ~ 0.9 1.15
playsound minecraft:entity.warden.sonic_boom master @a[distance=..64] ~ ~1 ~ 1.0 0.9
particle minecraft:sonic_boom ~ ~1.5 ~ 0.6 1.5 0.6 0.12 70
particle minecraft:end_rod ~ ~2.0 ~ 1.2 2.5 1.2 0.08 40
effect give @a[distance=..32] minecraft:slow_falling 5 0 true

title @a[distance=..64] times 12 65 18
title @a[distance=..64] subtitle {"text":"DANGER: Wardens & Quantum Matrices Breach the Core!","color":"gray"}
title @a[distance=..64] title {"text":"✦ ACT XVIII: CHRONOS & DEEP DARK RIFT ✦","color":"dark_aqua","bold":true}
tellraw @a[distance=..64] ["",{"text":"\n§8§m--------------------------------------------------\n"},{"text":"  ✦ ACT XVIII: CHRONOS & DEEP DARK RIFT ✦\n","color":"dark_aqua","bold":true},{"text":"  WARNING: The Anomaly has torn open a Deep Dark Rift—Wardens can now emerge from the pedestal!\n","color":"white"},{"text":"  §7(Right-click your Act Field Manual Book or Pedestal anytime for full details!)\n"},{"text":"§8§m--------------------------------------------------"}]
