scoreboard players set @s ob_phase 14
execute unless score #global_max ob_phase matches 14.. run scoreboard players set #global_max ob_phase 14
advancement grant @a only oneblock:phase14

playsound minecraft:ui.toast.challenge_complete master @a[distance=..64] ~ ~1 ~ 0.9 1.15
playsound minecraft:block.amethyst_block.resonate master @a[distance=..64] ~ ~1 ~ 1.0 0.9
particle minecraft:cherry_leaves ~ ~1.5 ~ 0.6 1.5 0.6 0.12 70
particle minecraft:end_rod ~ ~2.0 ~ 1.2 2.5 1.2 0.08 40
effect give @a[distance=..32] minecraft:slow_falling 5 0 true

title @a[distance=..64] times 12 65 18
title @a[distance=..64] subtitle {"text":"Pandas, Frogs, Camels & Atmospheric Biome Prisms!","color":"gray"}
title @a[distance=..64] title {"text":"✦ ACT XIV: BIOME TERRAFORMING & WILDLIFE ✦","color":"green","bold":true}
tellraw @a[distance=..64] ["",{"text":"\n§8§m--------------------------------------------------\n"},{"text":"  ✦ ACT XIV: BIOME TERRAFORMING & WILDLIFE ✦\n","color":"green","bold":true},{"text":"  Primordial wildlife flourishes! Use Atmospheric Biome Prisms to reshape your island's climate and flora!\n","color":"white"},{"text":"  §7(Right-click your Act Field Manual Book or Pedestal anytime for full details!)\n"},{"text":"§8§m--------------------------------------------------"}]
