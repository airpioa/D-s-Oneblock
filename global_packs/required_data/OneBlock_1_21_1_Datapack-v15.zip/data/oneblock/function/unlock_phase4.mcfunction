scoreboard players set @s ob_phase 4
execute unless score #global_max ob_phase matches 4.. run scoreboard players set #global_max ob_phase 4
advancement grant @a only oneblock:phase4

playsound minecraft:ui.toast.challenge_complete master @a[distance=..64] ~ ~1 ~ 0.9 1.15
playsound minecraft:entity.wolf.ambient master @a[distance=..64] ~ ~1 ~ 1.0 0.9
particle minecraft:heart ~ ~1.5 ~ 0.6 1.5 0.6 0.12 70
particle minecraft:end_rod ~ ~2.0 ~ 1.2 2.5 1.2 0.08 40
effect give @a[distance=..32] minecraft:slow_falling 5 0 true

title @a[distance=..64] times 12 65 18
title @a[distance=..64] subtitle {"text":"Wolves, Cats, Foxes, Parrots, Axolotls & Training Treats!","color":"gray"}
title @a[distance=..64] title {"text":"✦ ACT IV: LOYAL COMPANIONS & DOGGY TALENTS ✦","color":"gold","bold":true}
tellraw @a[distance=..64] ["",{"text":"\n§8§m--------------------------------------------------\n"},{"text":"  ✦ ACT IV: LOYAL COMPANIONS & DOGGY TALENTS ✦\n","color":"gold","bold":true},{"text":"  Loyal companions arrive! Tame Wolves with Bones, craft Doggy Talents Training Treats, and train your ultimate sky-companion!\n","color":"white"},{"text":"  §7(Right-click your Act Field Manual Book or Pedestal anytime for full details!)\n"},{"text":"§8§m--------------------------------------------------"}]
