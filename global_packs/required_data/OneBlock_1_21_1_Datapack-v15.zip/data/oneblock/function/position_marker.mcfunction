scoreboard players operation #step ob_id = @s ob_id
scoreboard players remove #step ob_id 1
execute if score #step ob_id matches 1.. run tp @s ~1024 ~ ~
execute if score #step ob_id matches 1.. run scoreboard players remove #step ob_id 1
execute if score #step ob_id matches 1.. run tp @s ~1024 ~ ~
execute if score #step ob_id matches 1.. run scoreboard players remove #step ob_id 1
execute if score #step ob_id matches 1.. run tp @s ~1024 ~ ~
execute if score #step ob_id matches 1.. run scoreboard players remove #step ob_id 1
execute if score #step ob_id matches 1.. run tp @s ~1024 ~ ~
execute if score #step ob_id matches 1.. run scoreboard players remove #step ob_id 1
execute if score #step ob_id matches 1.. run tp @s ~1024 ~ ~
execute if score #step ob_id matches 1.. run scoreboard players remove #step ob_id 1
execute if score #step ob_id matches 1.. run tp @s ~1024 ~ ~
execute if score #step ob_id matches 1.. run scoreboard players remove #step ob_id 1
execute if score #step ob_id matches 1.. run tp @s ~1024 ~ ~
execute if score #step ob_id matches 1.. run scoreboard players remove #step ob_id 1
execute if score #step ob_id matches 1.. run tp @s ~1024 ~ ~
execute if score #step ob_id matches 1.. run scoreboard players remove #step ob_id 1
execute if score #step ob_id matches 1.. run tp @s ~1024 ~ ~
execute if score #step ob_id matches 1.. run scoreboard players remove #step ob_id 1
execute if score #step ob_id matches 1.. run tp @s ~1024 ~ ~
execute if score #step ob_id matches 1.. run scoreboard players remove #step ob_id 1
execute if score #step ob_id matches 1.. run tp @s ~1024 ~ ~
execute if score #step ob_id matches 1.. run scoreboard players remove #step ob_id 1
execute if score #step ob_id matches 1.. run tp @s ~1024 ~ ~
execute if score #step ob_id matches 1.. run scoreboard players remove #step ob_id 1
execute if score #step ob_id matches 1.. run tp @s ~1024 ~ ~
execute if score #step ob_id matches 1.. run scoreboard players remove #step ob_id 1
execute if score #step ob_id matches 1.. run tp @s ~1024 ~ ~
execute if score #step ob_id matches 1.. run scoreboard players remove #step ob_id 1
execute if score #step ob_id matches 1.. run tp @s ~1024 ~ ~
execute if score #step ob_id matches 1.. run scoreboard players remove #step ob_id 1
execute if score #step ob_id matches 1.. run tp @s ~1024 ~ ~
execute if score #step ob_id matches 1.. run scoreboard players remove #step ob_id 1
execute if score #step ob_id matches 1.. run tp @s ~1024 ~ ~
execute if score #step ob_id matches 1.. run scoreboard players remove #step ob_id 1
execute if score #step ob_id matches 1.. run tp @s ~1024 ~ ~
execute if score #step ob_id matches 1.. run scoreboard players remove #step ob_id 1
execute if score #step ob_id matches 1.. run tp @s ~1024 ~ ~
execute if score #step ob_id matches 1.. run scoreboard players remove #step ob_id 1
execute if score #step ob_id matches 1.. run tp @s ~1024 ~ ~
execute if score #step ob_id matches 1.. run scoreboard players remove #step ob_id 1
execute if score #step ob_id matches 1.. run tp @s ~1024 ~ ~
execute if score #step ob_id matches 1.. run scoreboard players remove #step ob_id 1
execute if score #step ob_id matches 1.. run tp @s ~1024 ~ ~
execute if score #step ob_id matches 1.. run scoreboard players remove #step ob_id 1
execute if score #step ob_id matches 1.. run tp @s ~1024 ~ ~
execute if score #step ob_id matches 1.. run scoreboard players remove #step ob_id 1
execute if score #step ob_id matches 1.. run tp @s ~1024 ~ ~
execute if score #step ob_id matches 1.. run scoreboard players remove #step ob_id 1
execute if score #step ob_id matches 1.. run tp @s ~1024 ~ ~
execute if score #step ob_id matches 1.. run scoreboard players remove #step ob_id 1
execute if score #step ob_id matches 1.. run tp @s ~1024 ~ ~
execute if score #step ob_id matches 1.. run scoreboard players remove #step ob_id 1
execute if score #step ob_id matches 1.. run tp @s ~1024 ~ ~
execute if score #step ob_id matches 1.. run scoreboard players remove #step ob_id 1
execute if score #step ob_id matches 1.. run tp @s ~1024 ~ ~
execute if score #step ob_id matches 1.. run scoreboard players remove #step ob_id 1
execute if score #step ob_id matches 1.. run tp @s ~1024 ~ ~
execute if score #step ob_id matches 1.. run scoreboard players remove #step ob_id 1
execute if score #step ob_id matches 1.. run tp @s ~1024 ~ ~
execute if score #step ob_id matches 1.. run scoreboard players remove #step ob_id 1
execute if score #step ob_id matches 1.. run tp @s ~1024 ~ ~
execute if score #step ob_id matches 1.. run scoreboard players remove #step ob_id 1
execute if score #step ob_id matches 1.. run tp @s ~1024 ~ ~
execute if score #step ob_id matches 1.. run scoreboard players remove #step ob_id 1
