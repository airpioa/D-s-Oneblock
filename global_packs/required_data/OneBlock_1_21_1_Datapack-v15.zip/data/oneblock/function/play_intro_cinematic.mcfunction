scoreboard players remove @s ob_intro 1

execute if score @s ob_intro matches 159 run title @s times 15 45 15
execute if score @s ob_intro matches 159 run title @s subtitle {"text":"Initializing Dimensional Coordinates...","color":"aqua"}
execute if score @s ob_intro matches 159 run title @s title {"text":"✦ THE VOID ANOMALY ✦","color":"light_purple","bold":true}
execute if score @s ob_intro matches 159 run playsound minecraft:block.beacon.activate master @s ~ ~ ~ 1.0 0.7
execute if score @s ob_intro matches 159 run particle minecraft:portal ~ ~ ~ 1.5 2.0 1.5 0.1 60

execute if score @s ob_intro matches 40..158 run particle minecraft:end_rod ~ ~-1 ~ 0.8 0.4 0.8 0.02 4
execute if score @s ob_intro matches 40..158 run particle minecraft:enchant ~ ~1 ~ 1.2 1.2 1.2 0.2 8

execute if score @s ob_intro matches 100 run title @s times 10 45 10
execute if score @s ob_intro matches 100 run title @s subtitle {"text":"24 Acts • Global Biome Prism • Biome Surveyor","color":"gold"}
execute if score @s ob_intro matches 100 run title @s title {"text":"SURVIVE. TAME. AUTOMATE.","color":"white","bold":true}
execute if score @s ob_intro matches 100 run playsound minecraft:entity.illusioner.prepare_mirror master @s ~ ~ ~ 0.9 1.1

execute if score @s ob_intro matches 40 run title @s times 10 50 15
execute if score @s ob_intro matches 40 run title @s subtitle {"text":"Break the Grass Block above your Anomaly Pedestal!","color":"green"}
execute if score @s ob_intro matches 40 run title @s title {"text":"ACT I: A SPECK OF LIFE","color":"green","bold":true}
execute if score @s ob_intro matches 40 run playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 0.9 1.2
execute if score @s ob_intro matches 40 run particle minecraft:totem_of_undying ~ ~1 ~ 0.6 0.6 0.6 0.25 45

execute if score @s ob_intro matches 1 run tellraw @s ["",{"text":"§8§m==================================================\n"},{"text":"  ✦ WELCOME TO ONEBLOCK: 24-ACT SKY-VOID ✦\n","color":"light_purple","bold":true},{"text":"  • Assigned Island: ","color":"gray"},{"text":"#","color":"gold","bold":true},{"score":{"name":"@s","objective":"ob_id"},"color":"gold","bold":true},{"text":" (Spaced 1,024m apart along Z=0)\n","color":"dark_gray"},{"text":"  • Biome Changer: ","color":"gray"},{"text":"Works anywhere globally! Use Biome Surveyor to view borders!\n","color":"aqua"},{"text":"§8§m=================================================="}]
