execute as @a unless score @s ob_init matches 1 run function oneblock:create_player_island
execute as @a if score @s ob_intro matches 1.. run function oneblock:play_intro_cinematic
execute as @e[type=minecraft:marker,tag=ob_core] at @s run function oneblock:tick_island
scoreboard players add #hud_timer ob_hud 1
execute if score #hud_timer ob_hud matches 20.. run function oneblock:update_hud
execute if score #hud_timer ob_hud matches 20.. run scoreboard players set #hud_timer ob_hud 0
