scoreboard players set @s ob_phase 24
execute unless score #global_max ob_phase matches 24.. run scoreboard players set #global_max ob_phase 24
advancement grant @a only oneblock:phase24

playsound minecraft:ui.toast.challenge_complete master @a[distance=..64] ~ ~1 ~ 0.9 1.15
playsound minecraft:ui.toast.challenge_complete master @a[distance=..64] ~ ~1 ~ 1.0 0.9
particle minecraft:totem_of_undying ~ ~1.5 ~ 0.6 1.5 0.6 0.12 70
particle minecraft:end_rod ~ ~2.0 ~ 1.2 2.5 1.2 0.08 40
effect give @a[distance=..32] minecraft:slow_falling 5 0 true

title @a[distance=..64] times 12 65 18
title @a[distance=..64] subtitle {"text":"ALL 24 ACTS CONQUERED! Endless Nether Stars & Debris!","color":"gray"}
title @a[distance=..64] title {"text":"✦ ACT XXIV: INFINITE OMEGA SINGULARITY ✦","color":"yellow","bold":true}
tellraw @a[distance=..64] ["",{"text":"\n§8§m--------------------------------------------------\n"},{"text":"  ✦ ACT XXIV: INFINITE OMEGA SINGULARITY ✦\n","color":"yellow","bold":true},{"text":"  TRANSCENDENCE ACHIEVED! Ancient Debris, Netherite Blocks, Heavy Cores, and Nether Stars flow infinitely!\n","color":"white"},{"text":"  §7(Right-click your Act Field Manual Book or Pedestal anytime for full details!)\n"},{"text":"§8§m--------------------------------------------------"}]
