tag @a remove ob_joining
tag @e[type=minecraft:marker,tag=ob_new_core] remove ob_new_core

execute unless score #next_id ob_id matches 1.. run scoreboard players set #next_id ob_id 1
tag @s add ob_joining
scoreboard players operation @s ob_id = #next_id ob_id
scoreboard players add #next_id ob_id 1
scoreboard players set @s ob_init 1
scoreboard players set @s ob_intro 160

summon minecraft:marker 0.5 64.0 0.5 {Tags:["ob_core","ob_new_core"]}
execute as @e[type=minecraft:marker,tag=ob_new_core] run scoreboard players operation @s ob_id = @a[tag=ob_joining,limit=1] ob_id
execute as @e[type=minecraft:marker,tag=ob_new_core] run scoreboard players set @s ob_count 0
execute as @e[type=minecraft:marker,tag=ob_new_core] run scoreboard players set @s ob_phase 1

execute as @e[type=minecraft:marker,tag=ob_new_core] run function oneblock:position_marker
execute at @e[type=minecraft:marker,tag=ob_new_core] run forceload add ~ ~
execute at @e[type=minecraft:marker,tag=ob_new_core] run setblock ~ ~-1 ~ minecraft:air
execute at @e[type=minecraft:marker,tag=ob_new_core] run setblock ~ ~ ~ minecraft:grass_block
execute at @e[type=minecraft:marker,tag=ob_new_core] run function oneblock:apply_island_biome
execute at @e[type=minecraft:marker,tag=ob_new_core] run tp @a[tag=ob_joining] ~ ~6 ~
execute at @e[type=minecraft:marker,tag=ob_new_core] run spawnpoint @a[tag=ob_joining] ~ ~1 ~
tag @e[type=minecraft:marker,tag=ob_new_core] remove ob_new_core
tag @s remove ob_joining

execute unless score #global_max ob_phase matches 1.. run scoreboard players set #global_max ob_phase 1
advancement grant @s only oneblock:phase1
effect give @s minecraft:slow_falling 8 0 true
effect give @s minecraft:night_vision 10 0 true
