scoreboard players set #setup ob_init 1
scoreboard players set #schema ob_ver 15
scoreboard players set #next_id ob_id 1
setworldspawn 0 65 0
gamerule spawnRadius 0
