scoreboard players set @s ob_phase 19
execute unless score #global_max ob_phase matches 19.. run scoreboard players set #global_max ob_phase 19
advancement grant @a only oneblock:phase19

playsound minecraft:ui.toast.challenge_complete master @a[distance=..64] ~ ~1 ~ 0.9 1.15
playsound minecraft:entity.phantom.swoop master @a[distance=..64] ~ ~1 ~ 1.0 0.9
particle minecraft:end_rod ~ ~1.5 ~ 0.6 1.5 0.6 0.12 70
particle minecraft:end_rod ~ ~2.0 ~ 1.2 2.5 1.2 0.08 40
effect give @a[distance=..32] minecraft:slow_falling 5 0 true

title @a[distance=..64] times 12 65 18
title @a[distance=..64] subtitle {"text":"Solid Diamond/Emerald Vaults & Ender Phantoms!","color":"gray"}
title @a[distance=..64] title {"text":"✦ ACT XIX: CELESTIAL CRUCIBLE ✦","color":"light_purple","bold":true}
tellraw @a[distance=..64] ["",{"text":"\n§8§m--------------------------------------------------\n"},{"text":"  ✦ ACT XIX: CELESTIAL CRUCIBLE ✦\n","color":"light_purple","bold":true},{"text":"  Starlight condenses into solid gemstone vaults while high-altitude Phantoms circle your sky-fortress!\n","color":"white"},{"text":"  §7(Right-click your Act Field Manual Book or Pedestal anytime for full details!)\n"},{"text":"§8§m--------------------------------------------------"}]
