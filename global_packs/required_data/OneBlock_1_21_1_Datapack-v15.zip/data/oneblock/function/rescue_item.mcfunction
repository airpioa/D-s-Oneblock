tp @s ~ ~1.5 ~
data modify entity @s Motion set value [0.0d,0.15d,0.0d]
particle minecraft:portal ~ ~1.5 ~ 0.2 0.2 0.2 0.02 6
playsound minecraft:entity.enderman.teleport block @a[distance=..24] ~ ~1 ~ 0.25 1.6
