scoreboard players set @s ds_ob_init 1
tp @s 0.5 65.0 0.5
advancement grant @s only ds_void:mode_oneblock
ftbquests change_progress @s complete 3000000000000010
ftbquests change_progress @s complete 3000000000000020
tellraw @s ["",{"text":"[OneBlock Preset] ","color":"gold","bold":true},{"text":"Void World generated! Mine the block beneath you at (0, 64, 0) to progress!","color":"aqua"}]
