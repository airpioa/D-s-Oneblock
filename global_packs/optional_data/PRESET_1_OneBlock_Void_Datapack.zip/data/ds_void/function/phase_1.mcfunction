setblock 0 64 0 minecraft:grass_block
execute if predicate ds_void:chance_35 run setblock 0 64 0 minecraft:oak_log
execute if predicate ds_void:chance_15 run setblock 0 64 0 minecraft:dirt
execute if predicate ds_void:chance_10 run setblock 0 64 0 minecraft:clay
