# Auto-setup player on join
execute as @a unless score @s ds_ob_init matches 1 run function ds_void:init_player

# Infinite regenerating OneBlock at 0 64 0! Whenever it becomes air, increment counter and place next phase block
execute if block 0 64 0 minecraft:air run function ds_void:regen_oneblock
