scoreboard players add #blocks ob_count 1
execute if score #blocks ob_count matches 1..20 run function ds_void:phase_1
execute if score #blocks ob_count matches 21..60 run function ds_void:phase_2
execute if score #blocks ob_count matches 61..120 run function ds_void:phase_3
execute if score #blocks ob_count matches 121.. run function ds_void:phase_4
particle minecraft:happy_villager 0.5 64.8 0.5 0.3 0.3 0.3 0.05 8
playsound minecraft:block.grass.place block @a 0.5 64.5 0.5 0.6 1.2
