setblock 0 64 0 minecraft:stone
execute if predicate ds_void:chance_35 run setblock 0 64 0 minecraft:andesite
execute if predicate ds_void:chance_20 run setblock 0 64 0 minecraft:coal_ore
execute if predicate ds_void:chance_15 run setblock 0 64 0 minecraft:iron_ore
execute if predicate ds_void:chance_15 run setblock 0 64 0 minecraft:copper_ore
execute if predicate ds_void:chance_10 run setblock 0 64 0 minecraft:oak_log
