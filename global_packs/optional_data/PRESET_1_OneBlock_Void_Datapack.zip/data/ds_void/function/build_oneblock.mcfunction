scoreboard players set #island ds_world_ready 1
forceload add 0 0
setblock 0 63 0 minecraft:bedrock
setblock 0 64 0 minecraft:grass_block
setworldspawn 0 65 0
gamerule spawnRadius 0
