scoreboard objectives add ds_world_ready dummy
scoreboard objectives add ds_ob_init dummy
scoreboard objectives add ob_count dummy
execute unless score #island ds_world_ready matches 1 run function ds_void:build_oneblock
