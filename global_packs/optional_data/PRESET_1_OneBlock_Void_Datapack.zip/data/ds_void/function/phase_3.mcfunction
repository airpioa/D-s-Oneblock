setblock 0 64 0 minecraft:deepslate
execute if predicate ds_void:chance_25 run setblock 0 64 0 create:zinc_ore
execute if predicate ds_void:chance_25 run setblock 0 64 0 mekanism:osmium_ore
execute if predicate ds_void:chance_20 run setblock 0 64 0 minecraft:iron_ore
execute if predicate ds_void:chance_15 run setblock 0 64 0 minecraft:gold_ore
execute if predicate ds_void:chance_10 run setblock 0 64 0 minecraft:redstone_ore
