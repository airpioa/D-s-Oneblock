setblock 0 64 0 minecraft:stone
execute if predicate ds_void:chance_20 run setblock 0 64 0 ae2:quartz_ore
execute if predicate ds_void:chance_20 run setblock 0 64 0 mekanism:osmium_ore
execute if predicate ds_void:chance_15 run setblock 0 64 0 create:zinc_ore
execute if predicate ds_void:chance_15 run setblock 0 64 0 minecraft:diamond_ore
execute if predicate ds_void:chance_15 run setblock 0 64 0 minecraft:emerald_ore
execute if predicate ds_void:chance_10 run setblock 0 64 0 minecraft:nether_quartz_ore
