scoreboard objectives add ds_world_ready dummy
scoreboard objectives add ds_sf_init dummy
execute unless score #island ds_world_ready matches 1 run function ds_void:build_skyfactory_island
