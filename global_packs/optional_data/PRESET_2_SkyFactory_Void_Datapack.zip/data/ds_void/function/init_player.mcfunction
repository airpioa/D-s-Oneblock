scoreboard players set @s ds_sf_init 1
tp @s 1.5 64.0 1.5
advancement grant @s only ds_void:mode_skyfactory
ftbquests change_progress @s complete 3000000000000010
ftbquests change_progress @s complete 3000000000000030
tellraw @s ["",{"text":"[SkyFactory Preset] ","color":"green","bold":true},{"text":"Void Tree Island generated! Chop your tree and craft your way to tech!","color":"white"}]
