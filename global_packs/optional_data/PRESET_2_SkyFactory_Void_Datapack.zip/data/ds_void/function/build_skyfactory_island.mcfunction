scoreboard players set #island ds_world_ready 1
forceload add 0 0
# 3x3 Dirt/Grass Starter Island with Bedrock center & Starter Oak Tree
fill -1 63 -1 1 63 1 minecraft:dirt
setblock 0 63 0 minecraft:grass_block
setblock 0 62 0 minecraft:bedrock
# Starter Oak Tree at (-1, 64, -1)
setblock -1 64 -1 minecraft:oak_log
setblock -1 65 -1 minecraft:oak_log
setblock -1 66 -1 minecraft:oak_log
setblock -1 67 -1 minecraft:oak_log
fill -2 66 -2 0 67 0 minecraft:oak_leaves[persistent=false] replace minecraft:air
fill -1 68 -1 -1 68 -1 minecraft:oak_leaves[persistent=false]
setworldspawn 1 64 1
gamerule spawnRadius 0
