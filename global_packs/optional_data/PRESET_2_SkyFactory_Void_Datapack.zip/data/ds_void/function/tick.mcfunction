execute as @a unless score @s ds_sf_init matches 1 run function ds_void:init_player
